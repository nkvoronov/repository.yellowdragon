# -*- coding: utf-8 -*-

from resources.lib.epg import Epg

if (__name__ == "__main__"):
    Epg()

