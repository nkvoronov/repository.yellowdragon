# -*- coding: utf-8 -*-

from resources.lib.epg import Epg

Epg(1)