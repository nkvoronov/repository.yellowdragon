# -*- coding: utf8 -*-

import urllib.parse
import re

from lib.kodi65 import addon
from lib.kodi65 import utils
from lib.kodi65 import ItemList

BASE_URL = "https://api.discogs.com/"

def get_data():
	return None