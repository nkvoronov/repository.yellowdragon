# -*- coding: utf8 -*-

# Copyright (C) 2015 - Philipp Temminghoff <phil65@kodi.tv>
# This program is Free Software see LICENSE file for details

import xbmc
import xbmcgui

from lib.kodi65 import busy
from lib.kodi65 import utils


class VideoPlayer(xbmc.Player):

    def __init__(self, *args, **kwargs):
        utils.log('VideoPlayer.__init__')
        super(VideoPlayer, self).__init__()
        self.stopped = False

    def onPlayBackEnded(self):
        utils.log('VideoPlayer.onPlayBackEnded')
        self.stopped = True

    def onPlayBackStopped(self):
        utils.log('VideoPlayer.onPlayBackStopped')
        self.stopped = True

    def onPlayBackStarted(self):
        utils.log('VideoPlayer.onPlayBackStarted')
        self.stopped = False

    @busy.set_busy
    def youtube_info_by_id(self, youtube_id):
        utils.log('VideoPlayer.youtube_info_by_id')
        vid = utils.get_youtube_info(youtube_id)
        if not vid:
            return None, None
        listitem = xbmcgui.ListItem(label=vid.title)
        listitem.setArt({'thumb': vid.thumbnail})
        listitem.setInfo(type='video',
                         infoLabels={'genre': vid.sourceName,
                                     'plot': vid.description})
        return vid.streamURL(), listitem

    def wait_for_video_end(self):
        utils.log('VideoPlayer.wait_for_video_end')
        xbmc.sleep(500)
        while not self.stopped:
            xbmc.sleep(100)
        self.stopped = False
