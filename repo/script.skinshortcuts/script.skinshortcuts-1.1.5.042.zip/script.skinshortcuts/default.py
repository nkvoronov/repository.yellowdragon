from resources.lib import skinshortcuts

skinshortcuts.Main()
