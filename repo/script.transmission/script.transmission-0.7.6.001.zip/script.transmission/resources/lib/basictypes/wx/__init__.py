"""wxPython data-type models"""
