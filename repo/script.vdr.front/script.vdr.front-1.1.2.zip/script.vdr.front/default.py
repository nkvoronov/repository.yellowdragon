# -*- coding: utf-8 -*-
# Licence: GPL v.3 http://www.gnu.org/licenses/gpl.html

import sys
import os
import xbmc
import xbmcaddon

# Script constants
__settings__      = xbmcaddon.Addon(id = 'script.vdr.front')
__addon__         = xbmcaddon.Addon('script.vdr.front')
__cwd__           = __settings__.getAddonInfo('path')
__resources_lib__ = xbmc.translatePath(os.path.join(__cwd__, 'resources', 'lib'))

sys.path.append(__resources_lib__)

import functions

if (__name__ == "__main__"):
    functions.run_vdr_front()	    